
#include "gen_code.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Global pointers for the linked list
ThreeAddrInstr* head = NULL;
ThreeAddrInstr* lastInstruction = NULL;
extern int gen_3AC_flag;

void AppendInstruction(ThreeAddrInstr* instr) {
    if (!instr) return; // Safety check

    if (instr->op == OP_FUNC_DEF) {
        instr->next = head;
        head = instr;
        return;
    }

    if (head == NULL) {
        // If the list is empty, this instruction is the new head
        head = instr;
        lastInstruction = instr;
    }
    else {
        // Otherwise, append it to the end of the list
        lastInstruction->next = instr;
    }

    // Update lastInstruction to point to the new last instruction
    lastInstruction = instr;
}



ThreeAddrInstr* newInstruction(OpCode op, const char* arg1, const char* arg2, const char* result) {
    ThreeAddrInstr* instr = (ThreeAddrInstr*)malloc(sizeof(ThreeAddrInstr));
    instr->op = op;
    instr->arg1 = arg1 ? strdup(arg1) : NULL;
    instr->arg2 = arg2 ? strdup(arg2) : NULL;
    instr->result = result ? strdup(result) : NULL;
    instr->next = NULL;
    AppendInstruction(instr);
    return instr;
}


IdentifierNode* createIdentifierNode(const char* name) {
    IdentifierNode* node = (IdentifierNode*)malloc(sizeof(IdentifierNode));
    node->type = IDENTIFIER;
    node->name = strdup(name); // Ensure the string is duplicated to manage memory correctly
    return node;
}


// Wrapper function to initialize the context and start instruction generation
ThreeAddrInstr* generateInstructions(void* astNode) {
    ThreeAddrInstr* firstInstr = NULL;
    ThreeAddrInstr* lastInstruction = NULL; // This will be the tail of the list, updated throughout
    firstInstr = generateInstructionsRec(astNode, &lastInstruction);
    return firstInstr;
}

ThreeAddrInstr* generateInstructionsRec(void* astNode, ThreeAddrInstr** lastInstruction) {
    if (!astNode) return NULL;

    NodeType type = ast_node_type(astNode);
    ThreeAddrInstr* instr = NULL, * argInstr = NULL, * firstInstr = NULL;
    char result[20] = { 0 }, argBuff[50] = { 0 };
    char* arg1, * arg2;

    switch (type) {

    case FUNC_DEF: {
        FuncDefNode* defNode = (FuncDefNode*)astNode;
        setCurrentFuncParams(defNode); // Set the current function parameters
        // Function definitions might not directly translate into a 3-address instruction
        // but it's essential to handle the function body recursively and set up any necessary
        // environment or label for the function entry point.
        // For demonstration, we're marking the start of a function definition with a label (func name).
        char result[20];
        snprintf(result, sizeof(result), "%s", defNode->name);
        instr = newInstruction(OP_FUNC_DEF, NULL, NULL, result);
        instr->ArgCount = defNode->nargs;
        break;
    }

    case FUNC_CALL: {
        FuncCallNode* callNode = (FuncCallNode*)astNode;

        // Process each argument in the list
        ExprListNode* args = (ExprListNode*)func_call_args(callNode);
        int argIndex = 0;
        while (args) {
            if (ast_node_type(args->expr) == IDENTIFIER) {
                snprintf(argBuff, sizeof(argBuff), "%s", expr_id_name(args->expr));
            }
            else if (ast_node_type(args->expr) == INTCONST) {
                snprintf(argBuff, sizeof(argBuff), "%d", expr_intconst_val(args->expr));
            }

            // Generate an instruction to move the argument into the temporary variable
            argInstr = newInstruction(OP_PARAM, argBuff, NULL, NULL);

            args = args->next; // Next argument
            argIndex++;
        }

        char argCount[50] = { 0 };
        snprintf(argCount, sizeof(argCount), "%d", argIndex);

        // After processing arguments, generate the actual call instruction
        instr = newInstruction(CALL, func_call_callee(callNode), argCount, NULL);
        break;
    }
    case ASSG: {
        AssgNode* assgNode = (AssgNode*)astNode;

        // Left-hand side is directly used; no simplification expected for LHS
        char* lhsVarName = stmt_assg_lhs(assgNode); // Assuming this directly gives the variable name

        // Prepare to handle the RHS, which might have been replaced
        char* rhsVarName = NULL; // This will hold the name of the RHS variable or temp variable

        // Check if the RHS has been replaced and, if so, use the name of the replacement
        DummyNode* test = ((DummyNode*)assgNode);
        NodeType rhsNodeType = ast_node_type(assgNode->rhs);
        IdentifierNode* test1 = (IdentifierNode*)((IdentifierNode*)assgNode->rhs);

        IntConstNode* test3 = (IntConstNode*)((IntConstNode*)assgNode->rhs);
        IdentifierNode* test2 = (IdentifierNode*)test1->replacedWith;

        if (ast_node_type(assgNode->rhs) == INTCONST) {
            rhsVarName = (IntConstNode*)((IntConstNode*)assgNode->rhs)->replacedWith->name;
        }
        else {
            rhsVarName = (IdentifierNode*)((IdentifierNode*)assgNode->rhs)->replacedWith->name;
        }

        // Ensure rhsVarName is valid before proceeding
        if (!rhsVarName) {
            // Handle error: RHS is invalid or not replaced as expected
            break;
        }

        // Generate the assignment instruction
        ThreeAddrInstr* instr = newInstruction(OP_ASSIGN, rhsVarName, NULL, lhsVarName);
        break;
    }

    case ADD:
    case SUB:
    case MUL:
    case DIV: {
        BinaryExprNode* binNode = (BinaryExprNode*)astNode;

        // Generate temp variable for the result of this binary operation
        char* resultVarName = generateTmpVar();

        // Determine the operation type for correct opcode setting
        OpCode opcode = (type == ADD) ? OP_ADD :
            (type == SUB) ? OP_SUB :
            (type == MUL) ? OP_MUL : OP_DIV;

        // Use ast_node_type to dynamically handle operands based on their actual type
        char* operand1Var = NULL;
        char* operand2Var = NULL;

        // Safely determine if operands have been replaced and fetch the replacement name
        if (binNode->operand1 && ((BinaryExprNode*)binNode->operand1)->replaced) {
            operand1Var = ((BinaryExprNode*)binNode->operand1)->replacedWith->name;
        }
        if (binNode->operand2 && ((BinaryExprNode*)binNode->operand2)->replaced) {
            operand2Var = ((BinaryExprNode*)binNode->operand2)->replacedWith->name;
        }

        // Ensure operands are valid before proceeding
        if (!operand1Var || !operand2Var) {
            // Handle error: One or both operands are invalid or not replaced as expected
            break;
        }

        // Create the three-address instruction with the operands and result
        ThreeAddrInstr* instr = newInstruction(opcode, operand1Var, operand2Var, resultVarName);
        break;
    }



            // Define cases for other types as needed
    case IDENTIFIER: {
        IdentifierNode* idNode = (IdentifierNode*)astNode;

        // Check if this identifier is being used in a context that requires a temporary variable
        // This is a conceptual check; the actual condition depends on your specific use case
        char *tempVarName = generateTmpVar();

        // Generate a 3-address instruction that moves the identifier's value to the temp variable
        ThreeAddrInstr* instr = newInstruction(OP_ASSIGN, idNode->name, NULL, tempVarName);
        // Mark the identifier node as replaced with a temporary variable
        idNode->replaced = 1;
        idNode->replacedWith = createIdentifierNode(tempVarName);

        break;
    }

    case INTCONST: {
        IntConstNode* intConstNode = (IntConstNode*)astNode;

        // Generate a temporary variable name for the constant
        char *tempVarName = generateTmpVar();

        // Generate a 3-address instruction to hold the integer constant in a temporary variable
        // Assuming a utility function or direct formatting to convert int to string
        char intConstValue[20];
        snprintf(intConstValue, sizeof(intConstValue), "%d", intConstNode->value);

        ThreeAddrInstr* instr = newInstruction(OP_ASSIGN, intConstValue, NULL, tempVarName);
        // Mark the INTCONST node as replaced with the temporary variable
        intConstNode->replaced = 1;
        intConstNode->replacedWith = createIdentifierNode(tempVarName);
        break;
    }

    case IF:
    case WHILE:
    case RETURN:
    case STMT_LIST:
    case EXPR_LIST:
    case EQ:
    case NE:
    case LE:
    case LT:
    case GE:
    case GT:
        break;
    case UMINUS: {
        UnaryExprNode* uminusNode = (UnaryExprNode*)astNode;

        // Generate a temporary variable name for the result of this unary minus operation
        char *tempVarName = generateTmpVar();

        // Safely determine if the operand has been replaced and fetch the replacement name
        char* operandVar = NULL;
        if (((UnaryExprNode*)uminusNode->operand)->replaced) {
            operandVar = ((IdentifierNode*)((UnaryExprNode*)uminusNode->operand)->replacedWith)->name;
        }

        // Ensure operandVar is valid before proceeding
        if (!operandVar) {
            // Handle error: Operand is invalid or not replaced as expected
            break;
        }

        // Generate the 3-address instruction to negate the operand
        ThreeAddrInstr* instr = newInstruction(OP_UMINUS, operandVar, NULL, tempVarName);

        // Update the UMINUS node to indicate it's been replaced by the temporary variable
        uminusNode->replaced = 1;
        uminusNode->replacedWith = createIdentifierNode(tempVarName);

        break;
    }


    case AND:
    case OR:
        // Templates for remaining AST node types
        // Fill in logic as per AST node characteristics
        break;
    default:
        printf("Unhandled AST node type: %d\n", type);
        break;
    }


    
    // Additional logic to link and manage instructions if the node has children
    // This includes recursively calling generateInstructions on child nodes and linking the instructions

    return instr;
}

char* generateTmpVar() {
    static char buffer[20];
    snprintf(buffer, sizeof(buffer), "_tmp%d_", tmpCounter++);
    return buffer;
}


void appendInstruction(ThreeAddrInstr** head, ThreeAddrInstr** tail, ThreeAddrInstr* instr) {
    if (!*head) {
        *head = *tail = instr;
    }
    else {
        (*tail)->next = instr;
        *tail = instr;
    }
}


void traverseAndComposeInstructions(void* astNode, ThreeAddrInstr** lastInstruction) {
    if (!astNode) return;

    // Cast to DummyNode to check for the 'replaced' flag.

    // Based on the node type, recursively handle children first (post-order traversal).
    NodeType nodeType = ast_node_type(astNode);
    switch (nodeType) {
    case FUNC_DEF: {
        // Traverse function body
        FuncDefNode* funcDefNode = (FuncDefNode*)astNode;
        traverseAndComposeInstructions(funcDefNode->body, lastInstruction);
        break;
    }
    case IF: {
        // Traverse IF condition, then branch, and else branch (if exists)
        IfNode* ifNode = (IfNode*)astNode;
        traverseAndComposeInstructions(ifNode->expr, lastInstruction);
        traverseAndComposeInstructions(ifNode->then_branch, lastInstruction);
        if (ifNode->else_branch) {
            traverseAndComposeInstructions(ifNode->else_branch, lastInstruction);
        }
        break;
    }
    case WHILE: {
        // Traverse WHILE condition and body
        WhileNode* whileNode = (WhileNode*)astNode;
        traverseAndComposeInstructions(whileNode->expr, lastInstruction);
        traverseAndComposeInstructions(whileNode->body, lastInstruction);
        break;
    }
    case STMT_LIST:
    case EXPR_LIST: {
        // Traverse statement or expression list
        StmtListNode* currentNode = (StmtListNode*)astNode;
        while (currentNode) {
            traverseAndComposeInstructions(currentNode->stmt, lastInstruction);
            currentNode = (StmtListNode*)currentNode->next;
        }
        break;
    }
    case ASSG: {

        AssgNode* assgNode = (AssgNode*)astNode;
        traverseAndComposeInstructions(assgNode->rhs, lastInstruction);
        break;
    }
    default:
        // For nodes without children or simple nodes, no pre-processing is needed.
        break;
    }

    // After traversing child nodes, generate instructions for the current node.
    ThreeAddrInstr* newInstr = generateInstructionsRec(astNode, lastInstruction);
}

// Entry point to start the traversal and instruction generation process.
ThreeAddrInstr* startInstructionGeneration(void* root) {
    ThreeAddrInstr* firstInstr = NULL;
    traverseAndComposeInstructions(root, &firstInstr);
    return firstInstr; // The generated instructions are linked starting from firstInstr.
}


// Function to print a single 3AC instruction
void print3ACInstruction(ThreeAddrInstr* instr) {
    if (!instr) return;

    // Determine the operation type and format the instruction accordingly
    char opStr[20] = { 0 };
    switch (instr->op) {
    case OP_ADD: strcpy(opStr, "+"); break;
    case OP_SUB: strcpy(opStr, "-"); break;
    case OP_MUL: strcpy(opStr, "*"); break;
    case OP_DIV: strcpy(opStr, "/"); break;
        // Handle other operations accordingly...
    case CALL: strcpy(opStr, "call"); break;
    case OP_ASSIGN: strcpy(opStr, "="); break;
    case OP_PARAM: strcpy(opStr, "param"); break;
        // Add cases for other operations as needed
    default: strcpy(opStr, "UNKNOWN"); break;
    }

    if (gen_3AC_flag) {

        if (instr->op == CALL) {
            printf("%s %s, %s\n", opStr, instr->arg1, instr->arg2);
        }

        else if (instr->op == OP_PARAM) {
            printf("%s %s\n", opStr, instr->arg1);
        }

        else if (instr->arg2) { // For binary operations
            printf("%s = %s %s %s\n", instr->result, instr->arg1, opStr, instr->arg2);
        }
        else if (instr->arg1) { // For unary operations and assignments
            printf("%s %s %s\n", instr->result, opStr, instr->arg1);
        }
        else { // For labels and jumps
            printf("%s\n", instr->result);
        }
    }

    // Assume 'file' is a FILE* opened with fopen("instr.txt", "w") elsewhere in your code
    FILE* file = fopen("./instr.txt", "a");  // Open the file for writing, overwriting existing contents

    if (file == NULL) {
        perror("Error opening file");
        return;
    }

    else if (instr->op == CALL) {
        fprintf(file, "%s %s, %s\n", opStr, instr->arg1, instr->arg2);
    }
    else if (instr->op == OP_PARAM) {
        fprintf(file, "%s %s\n", opStr, instr->arg1);
    }
    else if (instr->arg2) { // For binary operations
        fprintf(file, "%s = %s %s %s\n", instr->result, instr->arg1, opStr, instr->arg2);
    }
    else if (instr->arg1) { // For unary operations and assignments
        fprintf(file, "%s %s %s\n", instr->result, opStr, instr->arg1);
    }
    else { // For labels and jumps
        fprintf(file, "%s\n", instr->result);
    }

    fclose(file);  // Make sure to close the file when you're done writing to it


}

// Function to traverse the AST, generate 3AC instructions, and print them
void print3ACInstructionsFromAST(void* rootAST) {

    startInstructionGeneration(rootAST);
    ThreeAddrInstr* currentInstr = head;

    //printf("Generated Three-Address Code (3AC) Instructions:\n");
    while (currentInstr != NULL) {
        print3ACInstruction(currentInstr);
        currentInstr = currentInstr->next;
    }

    PrintMIPSFromThreeAddrInstrs(head);

    // Freeing the allocated instructions and strings
    ThreeAddrInstr* temp;
    while (head != NULL) {
        temp = head;
        head = head->next;
        if (temp->arg1) free(temp->arg1);
        if (temp->arg2) free(temp->arg2);
        free(temp);
    }
}
