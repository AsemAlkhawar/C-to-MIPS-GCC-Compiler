
/*
 * File: ast.h
 * Author: Saumya Debray
 * Purpose: typedefs and prototypes for syntax trees
 */
#ifndef __AST_H__
#define __AST_H__







 /*******************************************************************************
  *                                                                             *
  *                                AST NODE TYPES                               *
  *                                                                             *
  *******************************************************************************/

typedef enum {
    DUMMY,            /* a placeholder */
    FUNC_DEF,         /* function definition */
    FUNC_CALL,        /* function call */
    IF,               /* if statement */
    WHILE,            /* while statement */
    ASSG,             /* assignment statement */
    RETURN,           /* return statement */
    STMT_LIST,        /* list of statements */
    EXPR_LIST,        /* list of expressions */
    IDENTIFIER,       /* identifier */
    INTCONST,         /* integer constant */
    EQ,               /* == */
    NE,               /* != */
    LE,               /* <= */
    LT,               /* < */
    GE,               /* >= */
    GT,               /* > */
    ADD,              /* + */
    SUB,              /* - (binary) */
    MUL,              /* * */
    DIV,              /* / */
    UMINUS,           /* - (unary) */
    AND,              /* && */
    OR                /* || */
} NodeType;

typedef struct IdentifierNode IdentifierNode; // Forward declaration

typedef struct DummyNode {
    NodeType type;  // DUMMY
    void* rhs;
    int replaced; // 0 if no, 1 if yes
    IdentifierNode* replacedWith;
    // Additional fields as needed
} DummyNode;

typedef struct FuncDefNode {
    NodeType type;  // FUNC_DEF
    char* name;     // Function name
    int nargs;      // Number of arguments
    char** argnames;// Array of argument names
    void* body;     // Pointer to the function body (a statement list)
} FuncDefNode;

typedef struct FuncCallNode {
    NodeType type;  // FUNC_CALL
    char* callee;   // Name of the function being called
    void* args;     // Pointer to the list of arguments (an expression list)
} FuncCallNode;

typedef struct IfNode {
    NodeType type;      // IF
    void* expr;         // Pointer to the conditional expression
    void* then_branch;  // Pointer to the then branch (a statement list)
    void* else_branch;  // Pointer to the else branch (a statement list), can be NULL
} IfNode;

typedef struct WhileNode {
    NodeType type;  // WHILE
    void* expr;     // Pointer to the conditional expression
    void* body;     // Pointer to the body of the loop (a statement list)
} WhileNode;

typedef struct AssgNode {
    NodeType type;  // ASSG
    char* lhs;      // Left-hand side identifier
    void* rhs;      // Pointer to the right-hand side expression
} AssgNode;

typedef struct ReturnNode {
    NodeType type;  // RETURN
    void* expr;     // Pointer to the return expression
} ReturnNode;

typedef struct IdentifierNode {
    NodeType type;  // IDENTIFIER
    char* name;     // Identifier name
    int replaced; // 0 if no, 1 if yes
    IdentifierNode* replacedWith;
} IdentifierNode;

typedef struct IntConstNode {
    NodeType type;  // INTCONST
    int value;      // Integer value
    int replaced; // 0 if no, 1 if yes
    IdentifierNode* replacedWith;
} IntConstNode;

typedef struct BinaryExprNode {
    NodeType type;      // One of EQ, NE, LE, LT, GE, GT, ADD, SUB, MUL, DIV, AND, OR
    void* operand1;     // Pointer to the first operand
    void* operand2;     // Pointer to the second operand
    int replaced; // 0 if no, 1 if yes
    IdentifierNode* replacedWith;
} BinaryExprNode;

typedef struct UnaryExprNode {
    NodeType type;  // UMINUS
    void* operand;  // Pointer to the operand
    int replaced; // 0 if no, 1 if yes
    IdentifierNode* replacedWith;
} UnaryExprNode;

typedef struct StmtListNode {
    NodeType type;       // STMT_LIST
    void* stmt;          // Pointer to the statement itself (e.g., IfNode, WhileNode, etc.)
    struct StmtListNode* next;  // Pointer to the next statement in the list
} StmtListNode;

typedef struct ExprListNode {
    NodeType type;       // EXPR_LIST
    void* expr;          // Pointer to the expression itself (e.g., IdentifierNode, IntConstNode, etc.)
    struct ExprListNode* next;  // Pointer to the next expression in the list
} ExprListNode;


/*******************************************************************************
 *                                                                             *
 *                           GETTERS FOR SYNTAX TREES                          *
 *                                                                             *
 *******************************************************************************/

 /*
  * ptr: an arbitrary non-NULL AST pointer; ast_node_type() returns the node type
  * for the AST node ptr points to.
  */
NodeType ast_node_type(void* ptr);

/*
 * ptr: pointer to an AST for a function definition; func_def_name() returns
 * a pointer to the function name (a string) of the function definition AST that
 * ptr points to.
 */
char* func_def_name(void* ptr);

/*
 * ptr: pointer to an AST for a function definition; func_def_nargs() returns
 * the number of formal parameters for that function.
 */
int func_def_nargs(void* ptr);

/*
 * ptr: pointer to an AST for a function definition, n is an integer. If n > 0
 * and n <= no. of arguments for the function, then func_def_argname() returns
 * a pointer to the name (a string) of the nth formal parameter for that function;
 * the first formal parameter corresponds to n == 1.  If the value of n is outside
 * these parameters, the behavior of this function is undefined.
 */
char* func_def_argname(void* ptr, int n);

/*
 * ptr: pointer to an AST for a function definition; func_def_body() returns
 * a pointer to the AST that is the function body of the function that ptr
 * points to.
 */
void* func_def_body(void* ptr);

/*
 * ptr: pointer to an AST node for a function call; func_call_callee() returns
 * a pointer to a string that is the name of the function being called.
 */
char* func_call_callee(void* ptr);

/*
 * ptr: pointer to an AST node for a function call; func_call_args() returns
 * a pointer to the AST that is the list of arguments to the call.
 */
void* func_call_args(void* ptr);

/*
 * ptr: pointer to an AST node for a statement list; stmt_list_head() returns
 * a pointer to the AST of the statement at the beginning of this list.
 */
void* stmt_list_head(void* ptr);

/*
 * ptr: pointer to an AST node for a statement list; stmt_list_rest() returns
 * a pointer to the AST of the rest of this list (i.e., the pointer to the
 * next node in the list).
 */
void* stmt_list_rest(void* ptr);

/*
 * ptr: pointer to an AST node for an expression list; expr_list_head() returns
 * a pointer to the AST of the expression at the beginning of this list.
 */
void* expr_list_head(void* ptr);

/*
 * ptr: pointer to an AST node for an expression list; expr_list_rest() returns
 * a pointer to the AST of the rest of this list (i.e., the pointer to the
 * next node in the list).
 */
void* expr_list_rest(void* ptr);

/*
 * ptr: pointer to an AST node for an IDENTIFIER; expr_id_name() returns a
 * pointer to the name of the identifier (a string).
 */
char* expr_id_name(void* ptr);

/*
 * ptr: pointer to an AST node for an INTCONST; expr_intconst_val() returns the
 * integer value of the constant.
 */
int expr_intconst_val(void* ptr);

/*
 * ptr: pointer to an AST node for an arithmetic or boolean expression.
 * expr_operand_1() returns a pointer to the AST of the first operand.
 */
void* expr_operand_1(void* ptr);

/*
 * ptr: pointer to an AST node for an arithmetic or boolean expression.
 * expr_operand_2() returns a pointer to the AST of the second operand.
 */
void* expr_operand_2(void* ptr);

/*
 * ptr: pointer to an AST node for an IF statement.  stmt_if_expr() returns
 * a pointer to the AST for the expression tested by the if statement.
 */
void* stmt_if_expr(void* ptr);

/*
 * ptr: pointer to an AST node for an IF statement.  stmt_if_then() returns
 * a pointer to the AST for the then-part of the if statement, i.e., the
 * statement to be executed if the condition is true.
 */
void* stmt_if_then(void* ptr);

/*
 * ptr: pointer to an AST node for an IF statement.  stmt_if_else() returns
 * a pointer to the AST for the else-part of the if statement, i.e., the
 * statement to be executed if the condition is false.
 */
void* stmt_if_else(void* ptr);

/*
 * ptr: pointer to an AST node for an assignment statement.  stmt_assg_lhs()
 * returns a pointer to the name of the identifier on the LHS of the
 * assignment.
 */
char* stmt_assg_lhs(void* ptr);

/*
 * ptr: pointer to an AST node for an assignment statement.  stmt_assg_rhs()
 * returns a pointer to the AST of the expression on the RHS of the assignment.
 */
void* stmt_assg_rhs(void* ptr);

/*
 * ptr: pointer to an AST node for a while statement.  stmt_while_expr()
 * returns a pointer to the AST of the expression tested by the while statement.
 */
void* stmt_while_expr(void* ptr);

/*
 * ptr: pointer to an AST node for a while statement.  stmt_while_body()
 * returns a pointer to the AST of the body of the while statement.
 */
void* stmt_while_body(void* ptr);

/*
 * ptr: pointer to an AST node for a return statement.  stmt_return_expr()
 * returns a pointer to the AST of the expression whose value is returned.
 */
void* stmt_return_expr(void* ptr);

/*******************************************************************************
 *                                                                             *
 *                         TOP-LEVEL AST PRINT ROUTINE                         *
 *                                                                             *
 *******************************************************************************/

 /*
  * print_ast(tree) takes a pointer to an AST node and uses the getter
  * functions supplied by the user to traverse and print the tree below
  * that node.
  */
void print_ast(void* tree);

#endif  /* __AST_H__ */