#pragma once
#include "ast.h"
#include "scanner.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef enum {
    CALL, // Assuming direct call for function calls
    OP_FUNC_DEF, // Adding an opcode for function definitions
    OP_ADD, OP_SUB, OP_MUL, OP_DIV, OP_ASSIGN,
    OP_GT, OP_LT, OP_GTE, OP_LTE, OP_EQ, OP_NEQ,
    OP_GOTO, OP_IF_GOTO, OP_LABEL, OP_UMINUS, OP_PARAM
    // Additional opcodes as necessary
} OpCode;




typedef struct ThreeAddrInstr {
    OpCode op;            // Operation code
    char* arg1;           // First operand
    char* arg2;           // Second operand, if applicable
    char* result;      // Result variable or label for control flow
    struct ThreeAddrInstr* next; // Next instruction in the list
    int ArgCount;
} ThreeAddrInstr;

static int tmpCounter = 1; // Global counter for temporary variable names

ThreeAddrInstr* newInstruction(OpCode op, const char* arg1, const char* arg2, const char* result);
IdentifierNode* createIdentifierNode(const char* name);
ThreeAddrInstr* generateInstructions(void* astNode);
ThreeAddrInstr* generateInstructionsRec(void* astNode, ThreeAddrInstr** lastInstruction);
char* generateTmpVar();
void appendInstruction(ThreeAddrInstr** head, ThreeAddrInstr** tail, ThreeAddrInstr* instr);
void traverseAndComposeInstructions(void* astNode, ThreeAddrInstr** lastInstruction);
void AppendInstruction(ThreeAddrInstr* instr);
void GenerateMIPS(ThreeAddrInstr* instr, FILE* outputFile);
void PrintMIPSFromThreeAddrInstrs(ThreeAddrInstr* head);
void printFileContents();
void appendFileContentsToFile(FILE* outputFile);
void print3ACInstruction(ThreeAddrInstr* instr);
char* getParamRegister(char* paramName);
void setCurrentFuncParams(FuncDefNode* funcDefNode);
char* GetTempRegisterForParam(int paramIndex);
int getTotalUsedRegisters();
void restoreCurrentRegisters(FILE* outputFile);
void storeCurrentRegisters(FILE* outputFile);
void move(FILE* outputFile, char* regDest, char* regSource);