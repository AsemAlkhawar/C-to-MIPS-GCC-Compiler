
#include "gen_code.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


// Global variable to keep track of the label count
static int labelCount = 2;
// Global pointers for the linked list
ThreeAddrInstr* head = NULL;
ThreeAddrInstr* lastInstruction = NULL;
extern int gen_3AC_flag;

void AppendInstruction(ThreeAddrInstr* instr) {
    if (!instr) return; // Safety check

    if (instr->op == OP_FUNC_DEF) {
        instr->next = head;
        head = instr;
        return;
    }

    if (head == NULL) {
        // If the list is empty, this instruction is the new head
        head = instr;
        lastInstruction = instr;
    }
    else {
        // Otherwise, append it to the end of the list
        lastInstruction->next = instr;
    }

    // Update lastInstruction to point to the new last instruction
    lastInstruction = instr;
}

// Function to generate a new unique label
char* generateLabel() {
    // Allocate memory for the label string
    char* label = (char*)malloc(20 * sizeof(char));
    if (!label) {
        fprintf(stderr, "Memory allocation failed for label\n");
        exit(EXIT_FAILURE);
    }

    // Generate the label string with a unique number
    snprintf(label, 20, "$L%d", labelCount);

    // Increment the label count for the next call
    labelCount++;

    return label;
}


ThreeAddrInstr* newInstruction(OpCode op, const char* arg1, const char* arg2, const char* result) {
    ThreeAddrInstr* instr = (ThreeAddrInstr*)malloc(sizeof(ThreeAddrInstr));
    instr->op = op;
    instr->arg1 = arg1 ? strdup(arg1) : NULL;
    instr->arg2 = arg2 ? strdup(arg2) : NULL;
    instr->result = result ? strdup(result) : NULL;
    instr->next = NULL;
    AppendInstruction(instr);
    return instr;
}


IdentifierNode* createIdentifierNode(const char* name) {
    IdentifierNode* node = (IdentifierNode*)malloc(sizeof(IdentifierNode));
    node->type = IDENTIFIER;
    node->name = strdup(name); // Ensure the string is duplicated to manage memory correctly
    return node;
}


// Wrapper function to initialize the context and start instruction generation
ThreeAddrInstr* generateInstructions(void* astNode) {
    ThreeAddrInstr* firstInstr = NULL;
    ThreeAddrInstr* lastInstruction = NULL; 
    firstInstr = generateInstructionsRec(astNode, &lastInstruction);
    return firstInstr;
}

ThreeAddrInstr* generateInstructionsRec(void* astNode, ThreeAddrInstr** lastInstruction) {
    if (!astNode) return NULL;

    NodeType type = ast_node_type(astNode);
    ThreeAddrInstr* instr = NULL, * argInstr = NULL, * firstInstr = NULL;
    char result[20] = { 0 }, argBuff[50] = { 0 };
    char* arg1, * arg2;

    switch (type) {

    case FUNC_DEF: {
        FuncDefNode* defNode = (FuncDefNode*)astNode;
        //setCurrentFuncParams(defNode); // Set the current function parameters

        char result[20];
        snprintf(result, sizeof(result), "%s", defNode->name);
        instr = newInstruction(OP_FUNC_DEF, NULL, NULL, result);
        instr->ArgCount = defNode->nargs;
        instr->argnames = defNode->argnames;
        break;
    }

    case FUNC_CALL: {
        FuncCallNode* callNode = (FuncCallNode*)astNode;

        // Process each argument in the list
        ExprListNode* args = (ExprListNode*)func_call_args(callNode);
        int argIndex = 0;
        while (args) {
            if (ast_node_type(args->expr) == IDENTIFIER) {
                snprintf(argBuff, sizeof(argBuff), "%s", expr_id_name(args->expr));
            }
            else if (ast_node_type(args->expr) == INTCONST) {
                snprintf(argBuff, sizeof(argBuff), "%d", expr_intconst_val(args->expr));
            }

            // Generate an instruction to move the argument into the temporary variable
            argInstr = newInstruction(OP_PARAM, argBuff, NULL, NULL);

            args = args->next; // Next argument
            argIndex++;
        }

        char argCount[50] = { 0 };
        snprintf(argCount, sizeof(argCount), "%d", argIndex);

        // After processing arguments, generate the actual call instruction
        instr = newInstruction(CALL, func_call_callee(callNode), argCount, NULL);
        break;
    }
    case ASSG: {
        AssgNode* assgNode = (AssgNode*)astNode;

        // Left-hand side is directly used; no simplification expected for LHS
        char* lhsVarName = stmt_assg_lhs(assgNode);

 
        char* rhsVarName = NULL; // This will hold the name of the RHS variable or temp variable

        // Check if the RHS has been replaced and, if so, use the name of the replacement
        DummyNode* test = ((DummyNode*)assgNode);
        NodeType rhsNodeType = ast_node_type(assgNode->rhs);

        if (ast_node_type(assgNode->rhs) == INTCONST) {
            rhsVarName = (IntConstNode*)((IntConstNode*)assgNode->rhs)->replacedWith->name;
        }
        else {
            rhsVarName = (IdentifierNode*)((IdentifierNode*)assgNode->rhs)->replacedWith->name;
        }

        // Ensure rhsVarName is valid before proceeding
        if (!rhsVarName) {
            // Handle error: RHS is invalid or not replaced as expected
            break;
        }

        // Generate the assignment instruction
        instr = newInstruction(OP_ASSIGN, rhsVarName, NULL, lhsVarName);
        break;
    }

    case ADD:
    case SUB:
    case MUL:
    case DIV:
        break;

    case IDENTIFIER: {
        IdentifierNode* idNode = (IdentifierNode*)astNode;


        char *tempVarName = generateTmpVar();

        // Generate a 3-address instruction that moves the identifier's value to the temp variable
        instr = newInstruction(OP_ASSIGN, idNode->name, NULL, tempVarName);
        // Mark the identifier node as replaced with a temporary variable
        idNode->replaced = 1;
        idNode->replacedWith = createIdentifierNode(tempVarName);

        break;
    }

    case INTCONST: {
        IntConstNode* intConstNode = (IntConstNode*)astNode;

        // Generate a temporary variable name for the constant
        char *tempVarName = generateTmpVar();

        char intConstValue[20];
        snprintf(intConstValue, sizeof(intConstValue), "%d", intConstNode->value);

        instr = newInstruction(OP_ASSIGN, intConstValue, NULL, tempVarName);
        // Mark the INTCONST node as replaced with the temporary variable
        intConstNode->replaced = 1;
        intConstNode->replacedWith = createIdentifierNode(tempVarName);
        break;
    }

    case IF: {
        IfNode* ifNode = (IfNode*)astNode;
        lastInstruction = generateInstructionsRec(ifNode->expr, lastInstruction);

        char* elseLabel = (ifNode->else_branch) ? generateLabel() : NULL;
        char* endLabel = generateLabel();

        if (ifNode->else_branch) {
            lastInstruction = newInstruction(OP_IF_GOTO, NULL, NULL, elseLabel);
            traverseAndComposeInstructions(ifNode->then_branch, *lastInstruction);
            lastInstruction = newInstruction(OP_GOTO, NULL, NULL, endLabel);
            lastInstruction = newInstruction(OP_LABEL, NULL, NULL, elseLabel);
            traverseAndComposeInstructions(ifNode->else_branch, *lastInstruction);
            lastInstruction = newInstruction(OP_LABEL, NULL, NULL, endLabel);
        }
        else {
            lastInstruction = newInstruction(OP_IF_GOTO, NULL, NULL, endLabel);
            traverseAndComposeInstructions(ifNode->then_branch, *lastInstruction);
            lastInstruction = newInstruction(OP_LABEL, NULL, NULL, endLabel);
        }

        break;
    }

    case WHILE: {
        WhileNode* whileNode = (WhileNode*)astNode;
        char* exprLabel = generateLabel();
        char* bodyLabel = generateLabel();

        lastInstruction = newInstruction(OP_GOTO, NULL, NULL, exprLabel);
        lastInstruction = newInstruction(OP_LABEL, NULL, NULL, bodyLabel);
        traverseAndComposeInstructions(whileNode->body, *lastInstruction);

        lastInstruction = newInstruction(OP_LABEL, NULL, NULL, exprLabel);

        ThreeAddrInstr* temp = generateInstructionsRec(whileNode->expr, lastInstruction);

        temp->ArgCount = 1;
        lastInstruction = temp;

        lastInstruction = newInstruction(OP_IF_GOTO, NULL, NULL, bodyLabel);
        break;
    }
    case RETURN:
    case EQ:
    case NE:
    case LE:
    case LT:
    case GE:
    case GT: {

        BinaryExprNode* expr = (BinaryExprNode*)astNode;
        char* operand1Str = NULL;
        char* operand2Str = NULL;

        // Check and handle the first operand
        if (ast_node_type(expr->operand1) == IDENTIFIER) {
            IdentifierNode* operand1 = (IdentifierNode*)expr->operand1;
            operand1Str = operand1->name;
        }
        else if (ast_node_type(expr->operand1) == INTCONST) {
            IntConstNode* operand1 = (IntConstNode*)expr->operand1;
            operand1Str = (char*)malloc(20 * sizeof(char));
            snprintf(operand1Str, 20, "%d", operand1->value);
        }

        // Check and handle the second operand
        if (ast_node_type(expr->operand2) == IDENTIFIER) {
            IdentifierNode* operand2 = (IdentifierNode*)expr->operand2;
            operand2Str = operand2->name;
        }
        else if (ast_node_type(expr->operand2) == INTCONST) {
            IntConstNode* operand2 = (IntConstNode*)expr->operand2;
            operand2Str = (char*)malloc(20 * sizeof(char));
            snprintf(operand2Str, 20, "%d", operand2->value);
        }

        // Convert the operation type to a string
        char* opTypeStr = (char*)malloc(20 * sizeof(char));
        switch (expr->type) {
        case GT:
            strcpy(opTypeStr, ">");
            break;
        case LT:
            strcpy(opTypeStr, "<");
            break;
        case GE:
            strcpy(opTypeStr, ">=");
            break;
        case LE:
            strcpy(opTypeStr, "<=");
            break;
        case EQ:
            strcpy(opTypeStr, "==");
            break;
        case NE:
            strcpy(opTypeStr, "!=");
            break;
        default:
            strcpy(opTypeStr, "UNKNOWN");
            break;
        }


        // Create the instruction
        instr = newInstruction(OP_BOOL, operand1Str, operand2Str, opTypeStr);

        if (ast_node_type(expr->operand1) == INTCONST) {
            free(operand1Str);
        }
        if (ast_node_type(expr->operand2) == INTCONST) {
            free(operand2Str);
        }


        break;
    }

    case UMINUS: {
        UnaryExprNode* uminusNode = (UnaryExprNode*)astNode;

        // Generate a temporary variable name for the result of this unary minus operation
        char *tempVarName = generateTmpVar();

        // Safely determine if the operand has been replaced and fetch the replacement name
        char* operandVar = NULL;
        if (((UnaryExprNode*)uminusNode->operand)->replaced) {
            operandVar = ((IdentifierNode*)((UnaryExprNode*)uminusNode->operand)->replacedWith)->name;
        }

        // Ensure operandVar is valid before proceeding
        if (!operandVar) {
            // Handle error: Operand is invalid or not replaced as expected
            break;
        }

        // Generate the 3-address instruction to negate the operand
        instr = newInstruction(OP_UMINUS, operandVar, NULL, tempVarName);

        // Update the UMINUS node to indicate it's been replaced by the temporary variable
        uminusNode->replaced = 1;
        uminusNode->replacedWith = createIdentifierNode(tempVarName);

        break;
    }


    case AND:
    case OR:
        // Templates for remaining AST node types

        break;
    default:
        printf("Unhandled AST node type: %d\n", type);
        break;
    }
    return instr;
}

char* generateTmpVar() {
    static char buffer[20];
    snprintf(buffer, sizeof(buffer), "__reg__");
    return buffer;
}


void traverseAndComposeInstructions(void* astNode, ThreeAddrInstr** lastInstruction) {
    if (!astNode) return;

    // Cast to DummyNode to check for the 'replaced' flag.

    NodeType nodeType = ast_node_type(astNode);
    switch (nodeType) {
    case FUNC_DEF: {
        // Traverse function body
        FuncDefNode* funcDefNode = (FuncDefNode*)astNode;
        traverseAndComposeInstructions(funcDefNode->body, lastInstruction);
        break;
    }
    case IF: {

        IfNode* ifNode = (IfNode*)astNode;
        //traverseAndComposeInstructions(ifNode->expr, lastInstruction);
        //traverseAndComposeInstructions(ifNode->then_branch, lastInstruction);
        //if (ifNode->else_branch) {
        //    traverseAndComposeInstructions(ifNode->else_branch, lastInstruction);
        //}
        break;
    }
    case WHILE: {
        // Traverse WHILE condition and body
        WhileNode* whileNode = (WhileNode*)astNode;
        //traverseAndComposeInstructions(whileNode->expr, lastInstruction);
        //traverseAndComposeInstructions(whileNode->body, lastInstruction);
        break;
    }
    case STMT_LIST:
    case EXPR_LIST: {
        // Traverse statement or expression list
        StmtListNode* currentNode = (StmtListNode*)astNode;
        while (currentNode) {
            traverseAndComposeInstructions(currentNode->stmt, lastInstruction);
            currentNode = (StmtListNode*)currentNode->next;
        }
        return;
        break;
    }
    case ASSG: {

        AssgNode* assgNode = (AssgNode*)astNode;
        traverseAndComposeInstructions(assgNode->rhs, lastInstruction);
        break;
    }
    default:
        //printf("Unhandled AST Node Type\n");
        break;
    }

    // After traversing child nodes, generate instructions for the current node.
    ThreeAddrInstr* newInstr = generateInstructionsRec(astNode, lastInstruction);
}

// Entry point to start the traversal and instruction generation process.
ThreeAddrInstr* startInstructionGeneration(void* root) {
    ThreeAddrInstr* firstInstr = NULL;
    traverseAndComposeInstructions(root, &firstInstr);
    return firstInstr; // The generated instructions are linked starting from firstInstr.
}


// Function to print a single 3AC instruction
void print3ACInstruction(ThreeAddrInstr* instr) {
    if (!instr) return;

    // Determine the operation type and format the instruction accordingly
    char opStr[20] = { 0 };
    switch (instr->op) {
    case OP_ADD: strcpy(opStr, "+"); break;
    case OP_SUB: strcpy(opStr, "-"); break;
    case OP_MUL: strcpy(opStr, "*"); break;
    case OP_DIV: strcpy(opStr, "/"); break;

    case CALL: strcpy(opStr, "call"); break;
    case OP_ASSIGN: strcpy(opStr, "="); break;
    case OP_PARAM: strcpy(opStr, "param"); break;

    default: strcpy(opStr, "UNKNOWN"); break;
    }

    if (gen_3AC_flag) {

        if (instr->op == CALL) {
            printf("%s %s, %s\n", opStr, instr->arg1, instr->arg2);
        }

        else if (instr->op == OP_PARAM) {
            printf("%s %s\n", opStr, instr->arg1);
        }

        else if (instr->arg2) { // For binary operations
            printf("%s = %s %s %s\n", instr->result, instr->arg1, opStr, instr->arg2);
        }
        else if (instr->arg1) { // For unary operations and assignments
            printf("%s %s %s\n", instr->result, opStr, instr->arg1);
        }
        else { // For labels and jumps
            printf("%s\n", instr->result);
        }
    }

    FILE* file = fopen("./instr.txt", "a");  // Open the file for writing, overwriting existing contents

    if (file == NULL) {
        perror("Error opening file");
        return;
    }

    else if (instr->op == CALL) {
        fprintf(file, "%s %s, %s\n", opStr, instr->arg1, instr->arg2);
    }
    else if (instr->op == OP_PARAM) {
        fprintf(file, "%s %s\n", opStr, instr->arg1);
    }
    else if (instr->arg2) { // For binary operations
        fprintf(file, "%s = %s %s %s\n", instr->result, instr->arg1, opStr, instr->arg2);
    }
    else if (instr->arg1) { // For unary operations and assignments
        fprintf(file, "%s %s %s\n", instr->result, opStr, instr->arg1);
    }
    else { // For labels and jumps
        fprintf(file, "%s\n", instr->result);
    }

    fclose(file);  


}

// Function to traverse the AST, generate 3AC instructions, and print them
void print3ACInstructionsFromAST(void* rootAST) {

    startInstructionGeneration(rootAST);
    ThreeAddrInstr* currentInstr = head;

    //printf("Generated Three-Address Code (3AC) Instructions:\n");
    while (currentInstr != NULL) {
        print3ACInstruction(currentInstr);
        currentInstr = currentInstr->next;
    }


    PrintMIPSFromThreeAddrInstrs(head);

    // Freeing the allocated instructions and strings
    ThreeAddrInstr* temp;
    while (head != NULL) {
        temp = head;
        head = head->next;
        if (temp->arg1) free(temp->arg1);
        if (temp->arg2) free(temp->arg2);
        free(temp);
    }
}


void printFileContents() {
    printf(".align 2\n"
        ".data\n"
        "_nl: .asciiz \"\\n\"\n"
        ".align 2\n"
        ".text\n"
        "# println: print out an integer followed by a newline\n"
        "println:\n"
        "li $v0, 1          # System call for print integer\n"
        "syscall            # Execute syscall (prints the integer in $a0)\n\n"
        "li $v0, 4          # System call for print string\n"
        "la $a0, _nl        # Load address of newline character into $a0\n"
        "syscall            # Execute syscall (prints newline)\n\n"
        "jr $ra             # Return to caller\n");
}


void appendFileContentsToFile(FILE* outputFile) {
    fprintf(outputFile, ".align 2\n"
        ".data\n"
        "_nl: .asciiz \"\\n\"\n"
        ".align 2\n"
        ".text\n"
        "# println: print out an integer followed by a newline\n"
        "println:\n"
        "li $v0, 1          # System call for print integer\n"
        "syscall            # Execute syscall (prints the integer in $a0)\n\n"
        "li $v0, 4          # System call for print string\n"
        "la $a0, _nl        # Load address of newline character into $a0\n"
        "syscall            # Execute syscall (prints newline)\n\n"
        "jr $ra             # Return to caller\n");
}



void generateDataSection(FILE* outputFile) {
    fprintf(outputFile, ".data\n");  // Start of the data section

    // Check if there is at least one scope (the global scope)
    if (currentScope >= 0) {
        SymbolTable* globalSymbolTable = &symbolTableStack[0];

        for (int i = 0; i < globalSymbolTable->size; i++) {
            if (globalSymbolTable->entries[i].type == VARIABLE) {
                // For each global variable, generate a line in the data section
                fprintf(outputFile, "%s: .space 4  # Global variable\n", globalSymbolTable->entries[i].name);
                printf("%s: .space 4  # Global variable\n", globalSymbolTable->entries[i].name);
            }
        }
    }

    fprintf(outputFile, "\n");  // End of the data section
    printf("\n");
}
